#pragma once
#ifndef PRINTMACHINE_H
#define PRINTMACHINE_H

#include <string>
#include <iostream>
using namespace std;

class PrintMachine 
{
    string model, manuf;
    int pcount, avlcount;
protected:
    PrintMachine(string model, string manuf, int avlcount);
    bool print(int pages);
    string get_model();
    string get_manuf();
    int get_avlcount();
};

class PrintInkJet : public PrintMachine 
{
    int avlink;
public:
    PrintInkJet(string model, string manuf, int avlcount, int avlink);
    bool printInkJet(int pages);
    void show();
};

class PrintLaser : public PrintMachine
{
    int avltoner;
public:
    PrintLaser(string model, string manuf, int avlcount, int avltoner);
    bool printLaser(int pages);
    void show();
};

#endif